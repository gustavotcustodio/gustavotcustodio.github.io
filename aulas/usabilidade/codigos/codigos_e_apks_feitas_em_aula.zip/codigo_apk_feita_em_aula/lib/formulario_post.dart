import 'package:flutter/material.dart';

class FormularioPost extends StatefulWidget {
  const FormularioPost({super.key});

  @override
  State<FormularioPost> createState() => _FormularioPostState();
}

class _FormularioPostState extends State<FormularioPost> {
  final controllerId = TextEditingController();
  final controllerNome = TextEditingController();
  final controllerPreco = TextEditingController();
  final controllerDescricao = TextEditingController();
  final controllerImagem = TextEditingController();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Adicionar Pizza"),
      ),
      body: Padding(
        padding: EdgeInsets.all(20),
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            _criarTextFormField(context, controllerId, "Id"),
            _criarTextFormField(context, controllerNome, "Nome"),
            _criarTextFormField(context, controllerDescricao, "Descrição"),
            _criarTextFormField(context, controllerPreco, "Preço"),
            _criarTextFormField(context, controllerImagem, "URL da imagem"),
            ElevatedButton(
              onPressed: () {
                //enviarForm();
              },
              child: Text('Adicionar'),
            ),
          ],
        ),
      ),
    );
  }

  Widget _criarTextFormField(
      BuildContext context, TextEditingController controller, String label) {
    // Cria um campo de texto com o Controller correspondente
    return TextFormField(
      controller: controller,
      decoration: InputDecoration(labelText: label),
    );
  }
}
