package com.example.teste_geracao_apk

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
