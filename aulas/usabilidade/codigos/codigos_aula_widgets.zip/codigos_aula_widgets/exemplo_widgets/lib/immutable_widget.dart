// Vamos criar uma classe que herda de Stateless
import 'package:flutter/material.dart';

class ImmutableWidget extends StatelessWidget {

  Widget build(BuildContext context) {
    // O Scaffold será a tela principal da sua aplicação
    return Scaffold(
      appBar: AppBar(title: Text("Treinando Widgets")),
      body: Container(
        color: Colors.green,
        // Padding serve para colocar um espaço entre retângulos
        child: Padding(
          // Estou dizendo que todas as bordas precisam de 40 de espaço
          padding: EdgeInsets.all(40),
          child: Container(
            color: Colors.purple,
            child: Padding(
              padding: EdgeInsets.all(70),
              child: Container(
                color: Colors.orange,
              ),
            ),
          ),
        ),
      ),
    );
  }
}
