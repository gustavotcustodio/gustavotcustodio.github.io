package com.example.exemplo_widgets

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
