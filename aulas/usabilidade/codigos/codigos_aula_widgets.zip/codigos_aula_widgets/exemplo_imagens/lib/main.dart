// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // Criar um método novo para uma parte do App
  AppBar _criarAppBar(BuildContext context) {
    return AppBar(
      title: Text('Imagens de Cachorro'),
      backgroundColor: Colors.indigoAccent,
      leading: Icon(Icons.menu),
      // ignore: prefer_const_literals_to_create_immutables
      actions: [
        Padding(
          padding: EdgeInsets.all(10),
          child: Icon(Icons.search),
        ),
        Padding(
          padding: EdgeInsets.all(10),
          child: Icon(Icons.edit),
        ),
        Padding(
          padding: EdgeInsets.all(10),
          child: Icon(Icons.save),
        ),
        Padding(
          padding: EdgeInsets.all(10),
          child: Icon(Icons.close),
        ),
      ],
    );
  }

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Imagens de Cachorro',
      theme: ThemeData(
        primarySwatch: Colors.blue,
      ),
      home: Scaffold(
        appBar: _criarAppBar(context),
        body: Center(
          // Columns tem três filhos
          child: Column(
            children: [
              Image.asset('images/dog1.jpeg'),
              Image.asset('images/dog2.jpg'),
              Image.asset('images/dog3.webp'),
            ],
          ),
        ),
      ),
    );
  }
}
