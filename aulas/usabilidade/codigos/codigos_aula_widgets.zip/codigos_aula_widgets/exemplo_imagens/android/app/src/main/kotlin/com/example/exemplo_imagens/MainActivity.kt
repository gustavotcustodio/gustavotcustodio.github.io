package com.example.exemplo_imagens

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
