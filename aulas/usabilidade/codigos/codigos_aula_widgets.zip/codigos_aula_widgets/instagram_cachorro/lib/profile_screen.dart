import 'package:flutter/material.dart';
import 'package:flutter/src/foundation/key.dart';
import 'package:flutter/src/widgets/framework.dart';

class ProfileScreen extends StatelessWidget {
  const ProfileScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Insta Dog'),
      ),
      // Coluna coloca tudo um embaixo do outro em ordem
      body: Column(
        children: [
          _buildProfileScreen(context),
          _buildProfileDetails(context),
          _buildActions(context)
        ],
      ),
    );
  }

  Widget _buildProfileScreen(BuildContext context) {
    return Container(
      width: 150,
      height: 150,
      child: Padding(
        padding: EdgeInsets.all(10),
        child: CircleAvatar(
          backgroundImage: NetworkImage(
              "https://i0.statig.com.br/bancodeimagens/2f/ym/i8/2fymi85z5vo5pcl5rsnsr3xgi.jpg"),
        ),
      ),
    );
  }

  Widget _buildProfileDetails(BuildContext context) {
    return Padding(
      padding: EdgeInsets.all(20),
      child: Column(
        // ignore: prefer_const_literals_to_create_immutables
        children: [
          // ignore: prefer_const_constructors
          Text(
            'Dog Caramelo',
            style: TextStyle(fontSize: 20),
          ),
          Center(
            child: _buildDetailsRow('Age', '4'),
          ),
          _buildDetailsRow('Status', 'Good Boy'),
        ],
      ),
    );
  }

  // Método para criar uma linha com informações
  Widget _buildDetailsRow(String heading, String value) {
    return Row(
      // Alinhamento da linha
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Text('$heading: '),
        Text(value),
      ],
    );
  }

  Widget _buildActions(BuildContext context) {
    return Row(
      mainAxisAlignment: MainAxisAlignment.center,
      children: [
        Icon(Icons.favorite),
        Icon(Icons.restaurant),
        Icon(Icons.directions_walk)
      ],
    );
  }
}
