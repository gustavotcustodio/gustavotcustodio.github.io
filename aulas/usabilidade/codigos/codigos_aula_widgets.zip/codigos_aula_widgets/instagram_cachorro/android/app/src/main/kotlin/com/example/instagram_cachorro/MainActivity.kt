package com.example.instagram_cachorro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
