
// mensagem é obrigatório, os outros parâmetros são opcionais
void parametrosComNome(String mensagem,
                       {int vezesMostrar = 1, 
                         String? despedida}) {

  for (int i = 0; i < vezesMostrar ; i++) {
    print(mensagem);
  }

  // Se passou a mensagem de despedida como parâmetro, use ela, caso contrário, mostra Tchau
  String mensagemDespedida = despedida ?? "Tchau";
  print(mensagemDespedida);
}

void main() {
	parametrosComNome("Bem vindo à aula", 
                    despedida: "Até logo");
}
