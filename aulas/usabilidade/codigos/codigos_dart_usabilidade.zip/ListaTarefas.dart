/* Crie uma lista de tarefas;
– crie uma classe que contém um método main.
– crie uma lista que armazene objetos do tipo String;
– cada tarefa será representada por uma string.
– adicione várias tarefas a sua lista.
– imprima o conteúdo de todas as mensagens.*/

void main() {
  List<String> tarefas = [];

  tarefas.add("Dar aula de noite");
  tarefas.add("Lavar a louça");

  tarefas.addAll(["limpar a casa", "consertar a torneira"]);

  for (String tarefa in tarefas) {
    print("Você precisa $tarefa");
  }

}