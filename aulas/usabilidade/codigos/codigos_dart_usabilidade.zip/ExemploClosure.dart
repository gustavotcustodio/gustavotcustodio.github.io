void conversar(String nome, Function(String) responder) {
  // Se eu passo a função como parâmetro, eu posso chamar ela
  print('Muito prazer, meu nome é $nome');

  responder(nome);
}

void main() {
  // responder é uma função que recebe uma String
	final responder = (String nome) { 
    print("Muito prazer, $nome");
  };

  // responder é um objeto
  // Aqui eu chamei a função
  conversar("João", responder);
}