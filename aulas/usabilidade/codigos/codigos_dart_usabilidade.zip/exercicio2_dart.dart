// recebo uma temperatura e uma função que converte a temperatura
void converterTemperatura(double temp, double Function(double) converter)
{
  double tempFinal = converter(temp);
  print("A temperatura final é $tempFinal.");
}

void main() {
  // Função que recebe temp em celsius e devolve para FAhrenheit
	final converterCelsiusParaFahrenheit = (double tempCelsius) {
    return 1.8 * tempCelsius  + 32;
  };

  final converterCelsiusParaKelvin = (double tempCelsius) {
    return tempCelsius + 273;
  };

  // Estou passando a temperatura e que tipo de conversão deve ser feita
  converterTemperatura(100, converterCelsiusParaFahrenheit);
  
}
