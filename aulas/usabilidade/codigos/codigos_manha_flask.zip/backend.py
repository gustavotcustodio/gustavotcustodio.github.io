from flask import Flask, render_template

app = Flask(__name__)
app.config["TEMPLATES_AUTO_RELOAD"] = True

@app.route('/')
def index():
    return render_template("index.html")

@app.route('/profile/<nome>')
def profile(nome):
    return render_template("profile.html",
                            nome=nome)


@app.route('/paginaestatica')
def estatica():
    return render_template('estatico.html')