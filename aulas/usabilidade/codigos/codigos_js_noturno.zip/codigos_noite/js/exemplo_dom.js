document.getElementById("botao").onclick = function () {
    let texto = document.getElementById("texto").value;
    document.getElementById(
        "divtitulo").innerHTML = `<h1>${texto}</h1>`;
}

