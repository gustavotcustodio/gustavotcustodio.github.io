function mouseEmCima() {
    let elemento = document.getElementById('botao');
    elemento.style.cursor = "hand";
    elemento.style.backgroundColor = "cyan";
    elemento.innerHTML = "Mouseover"
}

document.getElementById('botao').addEventListener(
    "mouseover", mouseEmCima
);

function mouseFora() {
    let elemento = document.getElementById('botao');
    elemento.style.backgroundColor = "white";
    elemento.innerHTML = "Mouse out"
}

document.getElementById('botao').addEventListener(
    "mouseout", mouseFora 
)