import "package:flutter/material.dart";
import "shared/firebase_authentication.dart";
import "package:firebase_core/firebase_core.dart";
import "firebase_options.dart";

class FormularioCadastro extends StatefulWidget {
  const FormularioCadastro({super.key});

  @override
  State<FormularioCadastro> createState() => _FormularioCadastroState();
}

class _FormularioCadastroState extends State<FormularioCadastro> {
  final TextEditingController txtUserName = TextEditingController();
  final TextEditingController txtPassword = TextEditingController();
  String _mensagem = "";
  FirebaseAuthentication? auth;

  Widget _criarTxtUserName(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: 128, right: 40),
      child: TextFormField(
        controller: txtUserName,
        decoration: InputDecoration(
          hintText: "E-mail Usuário",
          icon: Icon(Icons.verified_user),
        ),
      ),
    );
  }

  Widget _criarTxtSenha(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: 25, right: 40),
      child: TextFormField(
        controller: txtPassword,
        obscureText: true,
        decoration: InputDecoration(
          hintText: "Senha",
          icon: Icon(Icons.enhanced_encryption),
        ),
      ),
    );
  }

  Widget _criarBotaoCadastro(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: 50),
      child: ElevatedButton(
        onPressed: () {
          String userId = "";
          auth!.createUser(txtUserName.text, txtPassword.text).then((value) {
            if (value == null) {
              setState(() {
                _mensagem = 'Erro de cadastro.';
              });
            } else {
              userId = value;
              setState(() {
                _mensagem = 'Usuário $userId cadastrado.';
              });
            }
          });
        },
        child: Text('Cadastrar'),
      ),
    );
  }

  Widget _criarBotaoLogin(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(top: 50),
      child: ElevatedButton(
        onPressed: () {
          String userId = "";
          auth!.login(txtUserName.text, txtPassword.text).then((value) {
            if (value == null) {
              setState(() {
                _mensagem = 'Erro ao logar.';
              });
            } else {
              userId = value;
              setState(() {
                _mensagem = '$userId logado com sucesso.';
              });
            }
          });
        },
        child: Text('Logar'),
      ),
    );
  }

  Widget _criarCampoMensagem(BuildContext context) {
    return Text(
      _mensagem,
      style: TextStyle(
        fontSize: 16,
        color: Theme.of(context).primaryColorDark,
        fontWeight: FontWeight.bold,
      ),
    );
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Cadastro"),
      ),
      body: Column(
        children: [
          _criarTxtUserName(context),
          _criarTxtSenha(context),
          _criarBotaoCadastro(context),
          _criarBotaoLogin(context),
          _criarCampoMensagem(context),
        ],
      ),
    );
  }

  @override
  void initState() {
    Firebase.initializeApp(options: DefaultFirebaseOptions.currentPlatform)
        .whenComplete(() {
      auth = FirebaseAuthentication();
      setState(() {});
    });
    super.initState();
  }
}
