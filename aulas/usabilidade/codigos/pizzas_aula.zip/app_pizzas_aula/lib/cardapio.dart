import 'package:flutter/material.dart';
import 'httphelper.dart';
import 'model/pizza.dart';

class Cardapio extends StatefulWidget {
  const Cardapio({super.key});

  @override
  State<Cardapio> createState() => _PainelPizzariaState();
}

class _PainelPizzariaState extends State<Cardapio> {
  final HttpHelper helper = HttpHelper();

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Pizzaria")),
      body: FutureBuilder(
        future: helper.getListaPizzas(),
        builder: ((context, snapshot) {
          if (snapshot.hasData) {
            // Aqui se já terminou de processar o Future
            return _mostrarListaPizzas(context, snapshot.data!);
          } else {
            // Aqui se não terminou ainda
            return Center(
              child: CircularProgressIndicator(),
            );
          }
        }),
      ),
    );
  }

  ListView _mostrarListaPizzas(BuildContext context, List<Pizza> listaPizzas) {
    List<Widget> listTiles = [];

    // getListaPizzas é assíncrono, então quando terminar a operação o then é executado
    for (Pizza pizza in listaPizzas) {
      listTiles.add(
        ListTile(
          title: Text(pizza.nomePizza),
          subtitle: Text(
              "${pizza.descricao} - R\$ ${pizza.preco.toStringAsFixed(2)}"),
        ),
      );
    }
    return ListView(
      children: listTiles,
    );
  }
}
