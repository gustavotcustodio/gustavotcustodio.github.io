var paises = ["Brasil", "Japão", "Austrália"];

var capitais = {
    "Brasil": "Brasilia",
    "Japão": "Tóquio",
    "Austrália": "Canberra",
}

console.log(paises[0]);
console.log("A capital do Japão é " + capitais["Japão"]);