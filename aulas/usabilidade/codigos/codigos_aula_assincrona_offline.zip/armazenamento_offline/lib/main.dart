import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Armazenamento Offline',
      theme: ThemeData(
        // This is the theme of your application.
        //
        // Try running your application with "flutter run". You'll see the
        // application has a blue toolbar. Then, without quitting the app, try
        // changing the primarySwatch below to Colors.green and then invoke
        // "hot reload" (press "r" in the console where you ran "flutter run",
        // or simply save your changes to "hot reload" in a Flutter IDE).
        // Notice that the counter didn't reset back to zero; the application
        // is not restarted.
        primarySwatch: Colors.blue,
      ),
      home: MinhaPaginaPrincipal(),
    );
  }
}

class MinhaPaginaPrincipal extends StatefulWidget {
  const MinhaPaginaPrincipal({Key? key}) : super(key: key);

  @override
  State<MinhaPaginaPrincipal> createState() => _MinhaPaginaPrincipalState();
}

class _MinhaPaginaPrincipalState extends State<MinhaPaginaPrincipal> {
  int contadorApp = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Armazenamento Offline"),
      ),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: [
            Text("Você abriu o aplicativo $contadorApp vezes"),
            ElevatedButton(
              onPressed: deletarPreferencias,
              child: Text('Reiniciar Contador'),
            )
          ],
        ),
      ),
    );
  }

  Future lerEscreverPreferencias() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    int? valorSalvo = prefs.getInt('contadorApp');

    if (valorSalvo == null) {
      contadorApp = 1;
    } else {
      contadorApp = valorSalvo;
      contadorApp++;
    }
    // Salvar o contadorApp no armazenamento offline
    await prefs.setInt('contadorApp', contadorApp);

    setState(() {
      contadorApp = contadorApp;
    });
  }

  Future deletarPreferencias() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();

    await prefs.clear();

    setState(() {
      contadorApp = 0;
    });
  }

  @override
  void initState() {
    lerEscreverPreferencias();
    super.initState();
  }
}
