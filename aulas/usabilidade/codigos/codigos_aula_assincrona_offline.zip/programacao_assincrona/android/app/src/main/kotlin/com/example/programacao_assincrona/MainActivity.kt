package com.example.programacao_assincrona

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
