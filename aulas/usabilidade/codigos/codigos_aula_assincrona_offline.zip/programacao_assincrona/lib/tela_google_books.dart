import 'package:flutter/material.dart';
import 'dart:async';
import 'package:http/http.dart';
import 'package:http/http.dart' as http;

class PaginaFutura extends StatefulWidget {
  const PaginaFutura({Key? key}) : super(key: key);

  @override
  State<PaginaFutura> createState() => _PaginaFuturaState();
}

class _PaginaFuturaState extends State<PaginaFutura> {
  String resultado = "";

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text("Assíncrono"),
      ),
      body: Center(
        child: Column(children: [
          Spacer(), // adiciona um espaço entre elementos na coluna
          _criarBotaoDeBusca(context),
          Spacer(),
          Text(resultado.toString()),
        ]),
      ),
    );
  }

  Future<Response> getDadosAPI() async {
    final String dominio = 'www.googleapis.com';
    final String caminho = '/books/v1/volumes/junbDwAAQBAJ';
    Uri url = Uri.https(dominio, caminho);
    return http.get(url);
  }

  Widget _criarBotaoDeBusca(BuildContext context) {
    return ElevatedButton(
      child: Text('Buscar!'),
      onPressed: () async {
        resultado = '';
        setState(() {
          resultado = resultado;
        });
        /* Chama getDadosAPI e quando a future for completada,
        rode o codigo dentro do then */
        var valorRetorno = await getDadosAPI();
        resultado = valorRetorno.body.toString().substring(0, 450);
        setState(() {
          resultado = resultado;
        });
      },
    );
  }
}
