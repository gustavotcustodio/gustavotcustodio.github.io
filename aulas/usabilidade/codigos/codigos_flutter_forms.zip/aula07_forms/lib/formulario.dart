import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

class Formulario extends StatefulWidget {
  const Formulario({Key? key}) : super(key: key);

  @override
  State<Formulario> createState() => _FormularioState();
}

class _FormularioState extends State<Formulario> {
  final _formKey = GlobalKey<FormState>();

  final controllerNome = TextEditingController();
  String? _nomePais;
  List<String> listaPaises = ['Brasil', 'EUA', 'Argentina'];

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Formulário")),
      body: Form(
        key: _formKey,
        child: Padding(
          padding: EdgeInsets.all(15),
          child: Column(
            children: [
              _criarTextFormField(context),
              _criarDropdown(context),
              Spacer(),
              _criarBotaoDeSalvar(context),
              Spacer(),
            ],
          ),
        ),
      ),
    );
  }

  Widget _criarTextFormField(BuildContext context) {
    return TextFormField(
        controller: controllerNome,
        decoration: InputDecoration(labelText: "Nome"),
        validator: (text) {
          if (text!.isEmpty) {
            return "Erro, nome vazio.";
          }
          if (text.length < 3) {
            return "Seu nome precisa ter 3 letras no mínimo.";
          }
          return null;
        });
  }

  Widget _criarDropdown(BuildContext context) {
    return DropdownButtonFormField(
      hint: Text("Escolha um país"),
      items: listaPaises.map((element) {
        return DropdownMenuItem(
          value: element,
          child: Text(element),
        );
      }).toList(),
      value: _nomePais,
      onChanged: (String? paisEscolhido) {
        setState(() {
          _nomePais = paisEscolhido;
        });
      },
    );
  }

  Widget _criarBotaoDeSalvar(BuildContext context) {
    return ElevatedButton(
      onPressed: () async {
        final form = _formKey.currentState;
        // Validação do formulário
        if (form!.validate()) {
          _salvarInformacoes();

          showDialog(
            context: context,
            builder: (BuildContext context) {
              return AlertDialog(
                title: Text("Informações salvas"),
                content: Text("Informações salvas com sucesso"),
                actions: <Widget>[
                  // define os botões na base do dialogo
                  ElevatedButton(
                    child: Text("Ok"),
                    onPressed: () {
                      Navigator.of(context).pop();
                    },
                  ),
                ],
              );
            },
          );
        }
      },
      child: Text("Salvar Informação"),
    );
  }

  Future _salvarInformacoes() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear();

    if (_nomePais != null) {
      await prefs.setString("pais", _nomePais!);
    }
    await prefs.setString("nome", controllerNome.text);
    // Vamos chamar o alerta aqui
  }

  @override
  void initState() {
    _carregarInformacoes();
    super.initState();
  }

  Future _carregarInformacoes() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    controllerNome.text = prefs.getString("nome") ?? "";
    setState(() {
      _nomePais = prefs.getString("pais");
    });
  }
}
