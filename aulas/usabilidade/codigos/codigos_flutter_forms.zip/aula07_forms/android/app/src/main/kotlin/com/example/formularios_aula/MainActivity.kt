package com.example.formularios_aula

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
