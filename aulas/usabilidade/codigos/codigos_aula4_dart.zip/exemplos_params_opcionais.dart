void funcaoComOpcionais([String? nome, int? idade]) {
  // Nome e idade são opcionais
  // Se eu passei o parâmetro nome, receba ele, caso contrário, o nome verdadeiro é desconhecido
  final nomeVerdadeiro = nome ?? 'Desconhecido'; // pergunta se a variável é nula, se for, atribua o segundo caso
  final idadeVerdadeira = idade ?? 0;
  print('$nomeVerdadeiro tem $idadeVerdadeira anos.');
}

void main() {
	funcaoComOpcionais('Frederico', 8);
  funcaoComOpcionais();
}
