void containsString(String nome) {
  // Estou perguntando se dentro do nome existe o trecho Fred (retorna true ou false)
  if (nome.contains("F")) {
    print("O nome contém a letra F.");
  } else {
    print("O nome não contém F.");
  }
}

int retornaZero() 
{
  return 0;
}

void main() {
  int umInteiro = 10;
  // Se eu não defino tipo, ele assume
  var outroInteiro = 20;

  // Eu chamo aqui a função constainsString
  containsString("Frederico");

  // Printamos uma variável indicando ela com $
  print("A soma dos números $umInteiro e $outroInteiro é: ${umInteiro + outroInteiro}");

  // const zero = 0;
  String longaString = """
      Lorem ipsum dolor sit amet, consectetur adipiscing elit. Mauris in ullamcorper lectus, eget finibus urna. Proin ac pulvinar mauris. Class aptent taciti sociosqu ad litora torquent per conubia nostra, per inceptos himenaeos. Aliquam sollicitudin volutpat augue eget tincidunt. Vivamus fringilla lacus velit, eget efficitur lacus volutpat vel. Phasellus lacinia ex et maximus ultricies. Sed commodo orci leo, et interdum lorem imperdiet scelerisque. Integer sed enim ac ex mollis placerat. Fusce sit amet ultricies sem. Aliquam eget diam felis. Curabitur nec dignissim turpis. Nam molestie leo id sem sodales, ut bibendum lorem ornare.
    
    Donec vestibulum diam eget lacus convallis hendrerit. Mauris sed arcu a sapien blandit tempus at eget nisi. Aliquam condimentum dapibus ligula. Fusce faucibus dolor ut dapibus lobortis. Nullam vel tortor sapien. Aliquam tempus odio sodales lacinia euismod. Nunc fermentum sit amet sapien ac dignissim. Morbi sit amet aliquam arcu. Aliquam erat volutpat. Fusce laoreet, turpis cursus volutpat volutpat, purus libero vestibulum justo, vel hendrerit metus nisi quis quam. Praesent scelerisque id velit nec venenatis. Etiam at urna sit amet elit interdum porttitor ac quis dolor. Nunc cursus erat pellentesque iaculis dignissim. Duis quam tortor, porta fermentum fringilla at, gravida et nisl. Ut mollis imperdiet magna in laoreet. Aenean ac libero laoreet, suscipit magna ac, pretium justo.  
  """;

  print(longaString);
}
