import 'dart:io';

void exemploLeituraString() {
  print('Digite seu nome de usuário: ');
	String? usuario = stdin.readLineSync();
  print('Digite sua senha: ');
  String? senha = stdin.readLineSync();
  print('O usuário $usuario possui a senha $senha.');
}

void exemploLeituraNumero() {
  print("Digite um número de 1 a 100:");
  int numero = int.parse(stdin.readLineSync()!);
  print("Você digitou o número $numero");
}

void main() {
  exemploLeituraNumero();
}
