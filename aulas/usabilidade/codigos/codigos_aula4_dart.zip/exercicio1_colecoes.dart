void main() {
  Map<String, int> populacao = {
    "Índia": 1380,
    "Estados Unidos": 330,
    "China": 1440,
  };

  // Adicionando um novo elemento ao Map
  populacao['Brasil'] = 212;
  populacao.addAll(
    // Map é delimitado por {}
    { "Paquistão": 220,
      "Indonésia": 273,
      "Nigéria": 206,
      "Portugal": 15 }
  );

  for(MapEntry m in populacao.entries) {
    // Se é maior que 1000, estamos nos bilhões
    if (m.value > 1000) {
      // m.key é o nome do pais
      // m.value é a população
      print("${m.key} tem ${m.value / 1000} bilhões de habitantes.");   
    } else {
      print("${m.key} tem ${m.value} milhões de habitantes.");
    }
  }
}
