void main() {
  percorrendoColecoes();
}

void brincandoComMaps() {
  // String é a chave e int é o valor 
  Map<String, int> pontuacao = {
    'AAA': 10000,
    'Gabriel': 5000,
    'Pedro': 2000,
  };
  pontuacao["Pedro"] = 4000;
  // Adicionar pontuação da Mariana
  pontuacao['Mariana'] = 3500;

  // a key é pedro e o value é 2000
  print('A soma da pontuação de Mariana e Pedro é: ${pontuacao["Pedro"]! + pontuacao["Mariana"]!}');
}

void brincandoComConjuntos() {
  Set<int> numeros = {1, 2, 3, 5, 7};
  numeros.add(3);
  numeros.addAll({4, 6, 7});
  print(numeros);
}

void brincandoComListas() {
  List numeros = ['um', 2, 3, 5, 7];
  numeros.add(10);
  numeros.addAll([4, 1, 35]);

  // printa o tipo da lista
  print(numeros.runtimeType);
  
  print(numeros);
}

void percorrendoColecoes() {
  // Percorrendo uma lista
  List<int> numeros = [10, 9, 8, 7, 6, 5];
  for (int n in numeros) {
    print(n);
  }

  // Percorrer um map
  Map<String, double> salarios = {
    "João": 4000, // cada um desses é um MapEntry
    "Alfredo": 3000,
    "Joana": 5000
  };

  for (MapEntry m in salarios.entries) {
    // m.key chave - nome da pessoa
    // m.value valor - salário
    print("${m.key} ganha R\$${m.value}.");
  }
}
