import 'dart:io';
import 'package:http/http.dart' as http;
import 'dart:convert';
import 'model/pizza.dart';

class HttpHelper {
  final String dominio = "3d40g.mocklab.io";
  final String caminho = "pizzalist";

  Future<List<Pizza>> getListaPizzas() async {
    final List<Pizza> pizzas = [];
    Uri url = Uri.https(dominio, caminho);
    http.Response result = await http.get(url);

    if (result.statusCode == HttpStatus.ok) {
      final jsonResponse = json.decode(utf8.decode(result.bodyBytes));
      for (var response in jsonResponse) {
        var pizza = Pizza.fromJson(response);
        pizzas.add(pizza);
      }
    }
    return pizzas;
  }
}
