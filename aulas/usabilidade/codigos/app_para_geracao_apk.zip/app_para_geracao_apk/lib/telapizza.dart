import 'package:flutter/material.dart';
import 'model/pizza.dart';

class TelaPizza extends StatelessWidget {
  Pizza pizza;

  TelaPizza(this.pizza);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text(pizza.nomePizza),
      ),
      body: infoPizza(context),
    );
  }

  Widget infoPizza(BuildContext context) {
    return Column(
      children: [
        _imagem(context),
        _descricao(context),
        _preco(context),
      ],
    );
  }

  Widget _imagem(BuildContext context) {
    return Container(
      width: MediaQuery.of(context).size.width,
      child: Image.asset('${pizza.urlImagem}'),
    );
  }

  Widget _descricao(BuildContext context) {
    return Padding(
      padding: EdgeInsets.only(
        top: 50,
        bottom: 50,
      ),
      child: Text(
        '${pizza.descricao}',
        style: TextStyle(
          fontSize: 25,
          fontFamily: 'Courier',
        ),
      ),
    );
  }

  Widget _preco(BuildContext context) {
    return Text(
      'R\$ ${pizza.preco.toStringAsFixed(2)}',
      style: TextStyle(
        fontSize: 40,
        fontFamily: 'Courier',
        fontWeight: FontWeight.bold,
      ),
    );
  }
}
