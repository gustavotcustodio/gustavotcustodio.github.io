// ignore_for_file: prefer_const_constructors

import 'package:flutter/material.dart';
import 'cronometro.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.deepPurple,
      ),
      // Aqui instanciamos meu cronômetro
      home: TelaPrincipal(), //Cronometro(),
      initialRoute: '/',
      routes: {
        '/cronometro': (context) => Cronometro(),
      },
    );
  }
}

class TelaPrincipal extends StatelessWidget {
  const TelaPrincipal({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('TelaPrincipal'),
      ),
      body: Center(
        child: ElevatedButton(
          child: Text("Mudar de tela"),
          onPressed: () {
            Navigator.push(
              context,
              MaterialPageRoute(builder: (context) => Cronometro()),
            );
          },
        ),
      ),
      drawer: Drawer(child: _criarMenuDrawer(context)),
    );
  }

  Widget _criarMenuDrawer(BuildContext context) {
    return ListView(
      // ignore: prefer_const_literals_to_create_immutables
      children: [
        // ignore: prefer_const_constructors
        UserAccountsDrawerHeader(
          accountName: Text("GustavoTorres"),
          accountEmail: Text('gustavo.custodio@anhembi.br'),
        ),
        ListTile(
          leading: Icon(Icons.home),
          title: Text("Home Page"),
          subtitle: Text("Minha página principal"),
        ),
        ListTile(
          leading: Icon(Icons.timer),
          title: Text("Cronômetro"),
          onTap: () {
            Navigator.of(context).pushNamed('/cronometro');
          },
        ),
        ListTile(
          leading: Icon(Icons.close),
          title: Text("Fechar Menu"),
          onTap: () {},
        )
      ],
    );
  }
}

//onTap: ()=> widget.scaffoldKey.currentState.openDrawer(),