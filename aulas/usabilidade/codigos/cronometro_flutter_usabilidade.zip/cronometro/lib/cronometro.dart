import 'dart:async';
import 'package:flutter/material.dart';

class Cronometro extends StatefulWidget {
  @override
  State<Cronometro> createState() {
    // _CronometroState vai ser o State
    return _CronometroState();
  }
}

class _CronometroState extends State<Cronometro> {
  int segundos = 0;
  Timer? timer; // Widget que marca o tempo
  // de um período em período de tempo, ele vai executar um método

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cronometro'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: [
          // primeiro filho
          Center(
            child: Text(
                // Será mostrado o valor da variável segundos
                "${segundos} segundos",
                style: Theme.of(context).textTheme.headline4),
          ),
          // segundo filho
          Center(
            // Aqui é onde eu vou criar meu botão
            child: _criarBotaoDeResetar(context),
          ),
        ],
      ),
    );
  }

  // método que cria o botão
  Widget _criarBotaoDeResetar(BuildContext context) {
    // onPressed é o que acontece quando eu clico no botão, dessa forma ele recebe uma função
    return ElevatedButton(
      onPressed: zerarTimer,
      child: Text("Resetar"),
    );
  }

  void zerarTimer() {
    setState(() {
      segundos = 0;
    });
  }

  @override
  void initState() {
    super.initState();
    segundos = 0;
    timer = Timer.periodic(Duration(seconds: 1), _onTick);
  }

  // No método que o timer chama, é necessário receber Timer como param.
  void _onTick(Timer time) {
    // setstate é um método que recebe uma função como parâmetro
    setState(() {
      // A cada um segundo, o _onTick será chamado
      ++segundos;
    });
  }

  @override
  void dispose() {
    timer?.cancel();
    super.dispose();
  }
}
