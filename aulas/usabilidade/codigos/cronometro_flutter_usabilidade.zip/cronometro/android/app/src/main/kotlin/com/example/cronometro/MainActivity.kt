package com.example.cronometro

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
