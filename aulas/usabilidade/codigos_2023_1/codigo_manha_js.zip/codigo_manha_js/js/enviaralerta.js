var alertar = function() {
    alert("Você clicou no botão da página");
}