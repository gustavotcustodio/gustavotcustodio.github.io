document.write("Vamos contar: ");

// Isso é um loop
for (let i = 1; i <= 10; i++) {
    document.write("<h1>Contando " + i + "</h1><br>");
}