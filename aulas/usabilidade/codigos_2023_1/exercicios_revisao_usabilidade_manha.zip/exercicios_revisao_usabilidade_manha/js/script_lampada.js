function acender() {
    document.getElementById("lampada").src = "imagens/lampada_acesa.jpg";
}

function apagar() {
    document.getElementById("lampada").src = "imagens/lampada_apagada.jpg";
}
