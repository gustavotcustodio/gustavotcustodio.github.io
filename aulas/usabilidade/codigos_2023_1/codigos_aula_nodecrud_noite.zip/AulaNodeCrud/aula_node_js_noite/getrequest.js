var express = require('express');
var http = require('http');
var app = express();
var server = http.createServer(app);

// Se digitarmos no navegador localhost:3333, faremos uma requisição GET
app.get('/', function (req, res) {
    // Servidor manda a resposta da requisição de volta para o cliente
    res.send("<h1>Essa é a raiz do servidor</h1>");
});

app.get('/getrequest', function (req, res) {
    // Servidor manda a resposta da requisição de volta para o cliente
    res.send("<h1>Esse é o caminho do getrequest</h1>");
});

// Esperando na porta 3333
server.listen(3333, function () {
    console.log("Server listening on port: 3333");
});