var express = require('express');
var http = require('http');
var app = express();
var path = require("path");
var bodyParser = require('body-parser');

var sqlite3 = require('sqlite3').verbose();
// Cria um novo banco de dados
var db = new sqlite3.Database('./database/Empresa.db');

app.use(bodyParser.urlencoded({extended: false}));
var server = http.createServer(app);

app.get('/', function (req, res) {
    /* Envia como resposta o formulário html.
     * __dirname éa pasta do arquivo atual.
     */
    res.sendFile(path.join(__dirname, './formulario.html'));
});

app.get('/getrequest', function (req, res) {
    // Servidor manda a resposta da requisição de volta para o cliente
    res.send("<h1>Esse é o caminho do getrequest</h1>");
});

// Se digitarmos no navegador localhost:3333, faremos uma requisição POST
app.post('/mostrar', function(req, res){
    res.send("<p>Nome: " + req.body.nome + "</p>" +
        "<p>Idade: " + req.body.idade + "</p>" +
        "<p>Endereço: " + req.body.endereco + "</p>"
    );
});

app.post('/insert', function(req,res){
    db.serialize(()=>{
        db.run(
            // Adicionar um novo funcionário no banco
            "INSERT INTO Funcionario (id, nome, idade, endereco) " +
            "VALUES(?, ?, ?, ?)",
            // Aqui são os valores dos ?, que correspondem ao formulário
            [req.body.id, req.body.nome, req.body.idade, req.body.endereco],
            // Depois de rodar a instrução sql, essa função éexecutada
            function(err) {
                // Se houver algum problema na inserção, mostre um erro
                if (err) {
                    return console.log(err.message);
                }
                console.log("Novo funcionário adicionado com sucesso");
                // Se der tudo certo, ele devolve para o cliente essa mensagem
                res.send( "Novo funcionário com ID = " + req.body.id +
                    " e nome = "+req.body.nome);
            }
        );
    });
});

// Esperando na porta 3333
server.listen(3333, function () {
    console.log("Server listening on port: 3333");
});
