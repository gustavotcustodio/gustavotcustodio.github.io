var sqlite3 = require('sqlite3').verbose();
// Cria um novo banco de dados
var db = new sqlite3.Database('./database/Empresa.db');

// Cria a tabela funcionário mostrada anteriormente (se não existir)
db.run("CREATE TABLE IF NOT EXISTS Funcionario" +
       "( id INT NOT NULL," + // campo não nulo
       "nome VARCHAR (20) NOT NULL," + // nome tamanho 20
       "idade INT NOT NULL," +
       "endereco VARCHAR (25)," +
       "PRIMARY KEY (id) )"
);
console.log("Tabela Criada com sucesso");
