var app = angular.module('paisesApp', []);

app.controller('PaisesController', function($scope) {
    $scope.capitais = [{capital: 'Brasília', pais: 'Brasil'},
                        {capital: 'Madrid', pais: 'Espanha'},
                        {capital: 'Berlim', pais: 'Alemanha'}];
});