var express = require('express');
var http = require('http');
var app = express();
var path = require("path");
var bodyParser = require('body-parser');

var sqlite3 = require('sqlite3').verbose();
// Cria um novo banco de dados
var db = new sqlite3.Database('./database/Empresa.db');

app.use(bodyParser.urlencoded({ extended: false }));
var server = http.createServer(app);

app.get('/', function (req, res) {
    /* Envia como resposta o formulário html.
     * __dirname éa pasta do arquivo atual.
     */
    res.sendFile(path.join(__dirname, './formulario.html'));
});

app.get('/getrequest', function (req, res) {
    // Servidor manda a resposta da requisição de volta para o cliente
    res.send("<h1>Esse é o caminho do getrequest</h1>");
});

// Se digitarmos no navegador localhost:3333, faremos uma requisição POST
app.post('/mostrar', function (req, res) {
    res.send("<p>Nome: " + req.body.nome + "</p>" +
        "<p>Idade: " + req.body.idade + "</p>" +
        "<p>Endereço: " + req.body.endereco + "</p>"
    );
});

app.post('/insert', function (req, res) {
    db.serialize(() => {
        db.run(
            // Adicionar um novo funcionário no banco
            "INSERT INTO Funcionario (id, nome, idade, endereco) " +
            "VALUES(?, ?, ?, ?)",
            // Aqui são os valores dos ?, que correspondem ao formulário
            [req.body.id, req.body.nome, req.body.idade, req.body.endereco],
            // Depois de rodar a instrução sql, essa função éexecutada
            function (err) {
                // Se houver algum problema na inserção, mostre um erro
                if (err) {
                    return console.log(err.message);
                }
                console.log("Novo funcionário adicionado com sucesso");
                // Se der tudo certo, ele devolve para o cliente essa mensagem
                res.send("Novo funcionário com ID = " + req.body.id +
                    " e nome = " + req.body.nome);
            }
        );
    });
});

app.post('/select', function (req, res) {
    db.serialize(() => {
        db.each('SELECT id, nome FROM Funcionario WHERE id = ?',
            // encontre o funcionario com o id preenchido
            [req.body.id],
            // A função recebe um row que corresponde a uma linha da tabela
            function (err, row) {
                // row corresponde a linha encontrada
                // Erro caso o funcionário não seja encontrado
                if (err) {
                    res.send("Erro ao encontrar funcionário");
                    return console.error(err.message);
                }
                // Envia para o cliente o nome e o id do funcionário caso ele seja encontrado
                res.send(`<p>Id: ${row.id}</p> <p> Nome: ${row.nome}</p><hr>`);
                console.log("Funcionário encontrado");
            });
    });
});

// Lista todos os funcionários na tabela
app.get('/showall', function (req, res) {
    db.serialize(() => {
        //db.all() inclui todos os funcionarios
        db.all('SELECT id, nome FROM Funcionario',
            function (err, rows) {
                if (err) {
                    res.send("Erro ao encontrar funcionario");
                    return console.error(err.message);
                }
                var resultado = "";
                // Itera sobre todos os resultados retornados
                for (var row of rows) {
                    // Coloca o nome e id dos funcionários em parágrafos.
                    // Concatena nome e id dos funcionários na variável resultado.
                    resultado += `<p>Id: ${row.id}</p> <p> Nome: ${row.nome}</p><hr>`;
                }
                // No final, temos a variável resultado com todos funcionarios
                res.send(resultado);
                console.log("Funcionarios encontrados");
            });
    });
});

app.post('/update', function (req, res) {
    db.serialize(() => {
        db.run(
            // Atualizar um funcionário no banco
            "UPDATE Funcionario " +
            "SET id=?, nome=?, idade=?, endereco=? " +
            "WHERE id=?",
            // Aqui são os valores dos ?, que correspondem ao formulário
            [req.body.id, req.body.nome, req.body.idade, req.body.endereco,
            req.body.id],
            // Depois de rodar a o sql, essa função éexecutada
            function (err) {
                // Se houver algum problema no update, mostre um erro
                if (err) {
                    return console.log(err.message);
                }
                console.log("Registro atualizado.");
                res.send("Funcionário " + req.body.id +
                    " atualizado com sucesso.");
            }
        );
    });
});

// Esperando na porta 3333
server.listen(3333, function () {
    console.log("Server listening on port: 3333");
});
