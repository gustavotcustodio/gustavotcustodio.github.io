var variavel = 1;
console.log(typeof(variavel)); // Mostra number

variavel = "Olá";
console.log(typeof(variavel)); // Mostra string