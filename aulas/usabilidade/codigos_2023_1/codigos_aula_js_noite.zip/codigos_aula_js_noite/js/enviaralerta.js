var alertar = function() {
    alert("Você clicou em um botão da página.") 
}
