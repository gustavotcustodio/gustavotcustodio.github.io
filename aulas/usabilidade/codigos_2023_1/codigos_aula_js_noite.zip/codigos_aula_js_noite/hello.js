// Serve para escrever no console do navegador
console.log("Minha primeira página");

// Esse serve para escrever na própria página
document.write("Minha primeira página");