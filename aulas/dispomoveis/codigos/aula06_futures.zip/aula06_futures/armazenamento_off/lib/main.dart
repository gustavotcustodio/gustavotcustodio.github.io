import 'package:flutter/material.dart';
import 'package:shared_preferences/shared_preferences.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      theme: ThemeData(
        primarySwatch: Colors.deepOrange,
      ),
      home: MinhaPaginaPrincipal(),
    );
  }
}

class MinhaPaginaPrincipal extends StatefulWidget {
  const MinhaPaginaPrincipal({Key? key}) : super(key: key);

  @override
  State<MinhaPaginaPrincipal> createState() => _MinhaPaginaPrincipalState();
}

class _MinhaPaginaPrincipalState extends State<MinhaPaginaPrincipal> {
  int contadorApp = 0;

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(title: Text("Armazenamento Offline")),
      body: Center(
        child: Column(
          mainAxisAlignment: MainAxisAlignment.spaceEvenly,
          children: <Widget>[
            Text("Você abriu o aplicativo $contadorApp vezes.",
                style: DefaultTextStyle.of(context)
                    .style
                    .apply(fontSizeFactor: 0.8)),
            ElevatedButton(
              onPressed: deletarPreferencias,
              child: Text('Reiniciar Contador'),
            )
          ],
        ),
      ),
    );
  }

  Future deletarPreferencias() async {
    SharedPreferences prefs = await SharedPreferences.getInstance();
    await prefs.clear();
    setState(() {
      contadorApp = 0;
    });
  }

  Future lerEscreverPreferencias() async {
    // Criar instância
    SharedPreferences prefs = await SharedPreferences.getInstance();

    // Posso ter um contadorApp no armazenamento offline ou não
    // Procurando contadorApp no armazenamento offline
    int? valorSalvo = prefs.getInt('contadorApp');

    if (valorSalvo == null) {
      // Se é a primeira vez abrindo o app, o contador é 1
      contadorApp = 1;
    } else {
      // o contador está armazenado
      contadorApp = valorSalvo;
      contadorApp++; // somei um no número de acessos do app
    }

    /* A chave 'contadorApp' recebe como valor um número inteiro
      Exemplo: 'contadorApp': 2 */
    await prefs.setInt('contadorApp', contadorApp);
    setState(() {
      contadorApp = contadorApp;
    });
  }

  @override
  void initState() {
    lerEscreverPreferencias();
    super.initState();
  }
}
