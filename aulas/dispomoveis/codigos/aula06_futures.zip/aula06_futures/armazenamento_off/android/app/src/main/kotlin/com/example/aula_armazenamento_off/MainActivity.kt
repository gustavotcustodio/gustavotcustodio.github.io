package com.example.aula_armazenamento_off

import io.flutter.embedding.android.FlutterActivity

class MainActivity: FlutterActivity() {
}
