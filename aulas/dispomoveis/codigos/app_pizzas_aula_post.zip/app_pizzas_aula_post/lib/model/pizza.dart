class Pizza {
  int id;
  String nomePizza;
  String descricao;
  double preco;
  String urlImagem;

  Pizza(this.id, this.nomePizza, this.descricao, this.preco, this.urlImagem);

  Pizza.fromJson(Map<String, dynamic> json)
      : id = json["id"],
        nomePizza = json["nomePizza"],
        descricao = json["descricao"],
        preco = json["preco"],
        urlImagem = json["urlImagem"];

  Map<String, dynamic> toJson() {
    return {
      "id": id,
      "nomePizza": nomePizza,
      "descricao": descricao,
      "preco": preco,
      "urlImagem": urlImagem,
    };
  }
}
