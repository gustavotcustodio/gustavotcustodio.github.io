import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      home: BarraApp(),
    );
  }
}

class BarraApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        backgroundColor: Colors.amber,
        title: Text('Aplicativo do AppBar'),
        leading: Padding(
          padding: EdgeInsets.all(10),
          child: Icon(Icons.menu),
        ),
        actions: <Widget>[
          Padding(
            child: Icon(Icons.edit),
            padding: EdgeInsets.all(10),
          ),
          Padding(
            child: Icon(Icons.search),
            padding: EdgeInsets.all(10),
          ),
        ],
      ),
    );
  }
}
