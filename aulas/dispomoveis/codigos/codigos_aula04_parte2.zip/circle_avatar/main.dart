import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Flutter Demo',
      home: Scaffold(
        body: Container(
          color: Colors.blue,
          child: Row(
            children: [
              // um dos children de Row é o CircleAvatar
              Padding(
                padding: EdgeInsets.all(10),
                child: CircleAvatar(
                  backgroundImage: NetworkImage(
                      "https://conteudo.imguol.com.br/c/entretenimento/80/2017/04/25/a-atriz-zoe-saldana-como-neytiri-em-avatar-1493136439818_v2_4x3.jpg"),
                ),
              ),
              // O outro vai ser o Text
              Text("Essa é a imagem do\navatar"),
            ],
          ),
        ),
      ),
    );
  }
}
