import 'package:flutter/material.dart';
import './immutable_widget.dart';

void main() {
  runApp(const ExemploWidgets());
}

class ExemploWidgets extends StatelessWidget {
  const ExemploWidgets({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Welcome to Flutter',
      // precisamos escrever essa classe
      home: ImmutableWidget(),
    );
  }
}
