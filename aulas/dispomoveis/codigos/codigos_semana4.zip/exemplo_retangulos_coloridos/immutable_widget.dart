import 'package:flutter/material.dart';

class ImmutableWidget extends StatelessWidget {
  // Um widget sempre precisa ter um build
  Widget build(BuildContext context) {
    return Container(
        // parâmetro opcional
        color: Colors.green,
        // Dentro do container há um padding
        child: Padding(
          padding: const EdgeInsets.all(40),
          // Dentro do padding temos outro container
          child: Container(
            color: Colors.purple,
            child: Padding(
              padding: EdgeInsets.all(10),
              child: Container(
                color: Colors.blue,
              ),
            ),
          ),
        ));
  }
}
