import 'package:flutter/material.dart';

void main() {
  runApp(const MyApp());
}

class MyApp extends StatelessWidget {
  const MyApp({super.key});

  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Colunas e Linhas',
      home: Scaffold(
        appBar: AppBar(
          title: Text('Colunas e Linhas'),
        ),
        body: Center(
          child: Column(
            children: [
              Image.asset('images/lands_01.jpg'),
              Image.asset('images/lands_02.jpg'),
              Image.asset('images/lands_03.jpg'),
            ],
          ),
        ),
      ),
    );
  }
}
