double converterTemperatura(
  double temperatura,
  Function(double) funcaoConversao
) {
  return funcaoConversao(temperatura);
}

double converterCelsiusParaKelvin(double temperatura) {
  return temperatura + 273;
}

/*double converterCelsiusParaFahrenheit(double temperatura) {
  return temperatura * 9 / 5 + 32;
}*/

void main() {
  final converterCelsiusParaKelvin = 
    (double temperatura) => temperatura + 273;
  

  double tempFinal = converterTemperatura(
    100, converterCelsiusParaKelvin
  );
  print('A temperatura convertida é $tempFinal');
  //print(converteCelsiusParaKelvin(100));
}
