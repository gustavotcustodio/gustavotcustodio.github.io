void brincandoComListas() {
  
  List<int> numeros = [1, 2, 3, 5, 7];
  numeros.add(10);
  numeros.addAll([4, 1, 35]);
  print(numeros);
}

void brincandoComConjuntos() {
  Set<int> numeros = {1, 2, 3, 5, 7};
  numeros.add(3);
  numeros.addAll({4, 6, 7});
  print(numeros);
}

void brincandoComMaps()  {
  Map<String, int> pontuacao = {
    'AAA': 10000,
    'Gabriel': 5000,
    'Pedro': 2000,
  };
  
  pontuacao['Pedro'] = 30000;
  
  for (MapEntry elem in pontuacao.entries) {
    print("${elem.key} tem ${elem.value} pontos.");
  }
  //print("Pedro tem ${pontuacao['Pedro']} pontos.");
}

void main() {
  //brincandoComListas();
  // brincandoComConjuntos();
  brincandoComMaps();
}
