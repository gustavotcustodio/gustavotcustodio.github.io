void parametrosComNome(
  String mensagem,
  {int vezesMostrar = 1, String? despedida})
{
  for (int i = 0; i < vezesMostrar; i++) {
    print(mensagem);
  }
  String mensagemDespedida = despedida ?? 'Tchau';
  print(mensagemDespedida);
}

void conversar(String nome, Function(String) resposta) {
  print('Muito prazer, meu nome é $nome.');
  resposta(nome);
}

void main() {
  //exercicio1();
  /*parametrosComNome('Temos muitos parâmetros',
                    vezesMostrar: 5,
                    despedida: 'Adeus');*/
  final resposta = (String nome) => print('Olá $nome');
  conversar('Alexandre', resposta);
}
