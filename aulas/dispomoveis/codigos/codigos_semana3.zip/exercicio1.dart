void exercicio1() {
  Map<String, int> populacoes = {
    'Brasil': 200,
    'Estados Unidos': 300,
    'Espanha': 40,
    'Portugal': 15,
  };
  
  populacoes['Japão'] = 100;
  for(MapEntry me in populacoes.entries) {
    print('${me.key} tem ${me.value} milhões de habitantes.');
  }
}

void main() {
    exercicio1()
}
