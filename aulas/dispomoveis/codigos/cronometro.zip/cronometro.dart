import 'package:flutter/material.dart';
import 'dart:async'; // Onde está nosso timer

class Cronometro extends StatefulWidget {
  //retorna um State<Classe>
  State<Cronometro> createState() {
    return _CronometroState();
  }
}

// Aqui é a classe que representa nosso estado
class _CronometroState extends State<Cronometro> {
  int segundos = 0;
  Timer? timer;

  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Cronômetro'),
      ),
      body: Column(
        mainAxisAlignment: MainAxisAlignment.center,
        children: <Widget>[
          Center(
            child: Text(
              '$segundos segundos.',
              // Mudar o tamanho da fonte
              style: Theme.of(context).textTheme.headline5,
            ),
          ),
          Center(
            child: _criarBotaoDeResetar(context),
          )
        ],
      ),
    );
  }

  Widget _criarBotaoDeResetar(BuildContext context) {
    return ElevatedButton(
      // Quando apertamos o botão, zeramos o contador
      onPressed: zerarCronometro,
      child: Text("Resetar"),
    );
  }

  void zerarCronometro() {
    setState(() {
      segundos = 0;
    });
  }

  @override
  void initState() {
    super.initState();
    segundos = 0;
    // A função que passamos para o Timer precisa receber o Timer como parâmetro
    timer = Timer.periodic(Duration(seconds: 1), _onTick);
  }

  void _onTick(Timer timer) {
    // setState muda o estado do aplicativo, fazendo com que o Flutter redesenhe ele
    setState(() {
      ++segundos;
    });
  }

  @override
  void dispose() {
    // para o timer
    timer?.cancel();
    super.dispose();
  }
}
