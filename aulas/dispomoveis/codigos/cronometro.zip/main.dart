import 'package:flutter/material.dart';
import './cronometro.dart';

void main() {
  runApp(const AppCronometro());
}

class AppCronometro extends StatelessWidget {
  const AppCronometro({Key? key}) : super(key: key);

  // This widget is the root of your application.
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'Cronometro',
      home: TelaPrincipal(),
    );
  }
}

// Uma tela antes do cronômetro
class TelaPrincipal extends StatelessWidget {
  const TelaPrincipal({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Página Principal'),
      ),
      body: Center(
        child: ElevatedButton(
          child: Text('Mudar de tela'),
          onPressed: () {
            // Clicando nesse botão, vamos para a tela de cronômetro
            Navigator.push(
              context,
              MaterialPageRoute(
                builder: (context) => Cronometro(),
              ),
            );
          },
        ),
      ),
    );
  }
}
