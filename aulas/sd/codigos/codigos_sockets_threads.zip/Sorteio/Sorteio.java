import java.util.Random;

public class Sorteio implements Runnable {
    Gerenciador gerenciador;

    Sorteio(Gerenciador gerenciador) {
        this.gerenciador = gerenciador;
    }

    public static void main(String[] args) {
        Gerenciador gerenciador = new Gerenciador();
        Thread s1 = new Thread(new Sorteio(gerenciador));
        Thread s2 = new Thread(new Sorteio(gerenciador));
        Thread s3 = new Thread(new Sorteio(gerenciador));
        Thread s4 = new Thread(new Sorteio(gerenciador));

        s1.start();
        s2.start();
        s3.start();
        s4.start();
    }

    public void run() {
        int numeroSorteado;
        Random gerador = new Random();
        for (int i = 0; i < 100; i++) {
            numeroSorteado = gerador.nextInt(60) + 1;
            System.out.println("Sorteei o " + numeroSorteado);
            try {
                gerenciador.salvarNumeroSorteado(numeroSorteado);
            } catch (Exception e) {
                e.printStackTrace();
            }
        }
    }
    /*
    public synchronized void salvarNumeroSorteado(int numero) throws IOException {
        FileWriter fw = new FileWriter("resultado.txt", true);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter out = new PrintWriter(bw);
        out.println("\nSorteio número " + contagem);
        out.println(numero);
        out.close();
        contagem++;
    }*/
}
