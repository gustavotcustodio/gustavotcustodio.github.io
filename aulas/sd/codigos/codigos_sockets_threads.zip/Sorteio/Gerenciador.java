import java.io.*;

public class Gerenciador {
    int contagem = 1;

    public void salvarNumeroSorteado(int numero) throws IOException {
        FileWriter fw = new FileWriter("resultado.txt", true);
        BufferedWriter bw = new BufferedWriter(fw);
        PrintWriter out = new PrintWriter(bw);
        out.println("\nSorteio número " + contagem);
        out.println(numero);
        out.close();
        contagem++;
    }
}
