public class ParImpar implements Runnable {
    int numeroThread;

    public static void main(String[] args) {
        ParImpar p1 = new ParImpar(1);
        Thread pi1 = new Thread(p1);
        ParImpar p2 = new ParImpar(2);
        Thread pi2 = new Thread(p2);
        ParImpar p3 = new ParImpar(3);
        Thread pi3 = new Thread(p3);
        ParImpar p4 = new ParImpar(4);
        Thread pi4 = new Thread(p4);

        pi1.start();
        pi2.start();
        pi3.start();
        pi4.start();
    }

    ParImpar(int numeroThread) {
        this.numeroThread = numeroThread;
    }

    public void run() {
        for (int i = 0; i < 100; i++) {
            int parOuImpar = numeroThread % 2;
            if (parOuImpar == 1) {
                System.out.println("A thread " + numeroThread + " é ímpar.");
            } else {
                System.out.println("A thread " + numeroThread + " é par.");
            }
        }
    }
}