/**
 *
 * @author biizuka
 */
// Implementando a interface remota
public class HelloImpl implements Hello {  
   
   // Implementação do método printMsg
   public void printMsg() {  
      System.out.println("[UAM -  SD] Este é um programa de RMI");  
   } 
   
}
