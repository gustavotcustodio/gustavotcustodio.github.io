/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

/**
 *
 * @author bmoritani
 */
public class Client {
    public static void main(String[] args) {
        try {
            Scanner sc = new Scanner(System.in);
            // Pegando o registro 
            Registry registry = LocateRegistry.getRegistry("localhost", 18000);

            // Procurando por um registro que utilize a Interface Calculadora
            Calculadora stub = (Calculadora) registry.lookup("Calculadora");

            while(true) {
                System.out.println("Digite a operação:\n" +
                    "1 - Soma\n" +
                    "2 - Subtração\n" +
                    "3 - Multiplicação\n" +
                    "4 - Divisão"
                );
                int operacao = sc.nextInt();
                if (operacao < 0 || operacao > 4) {
                    System.out.println("Operação inválida");
                    break;
                } else {
                    realizarOperacao(sc, stub, operacao);
                }
            }
            
        } catch (Exception e) {
            System.err.println("Exceção do Cliente: " + e.toString());
            e.printStackTrace();
        }
    }

    public static void realizarOperacao(Scanner sc, Calculadora stub, int operacao) {
        try {
            System.out.println("Digite o primeiro valor:");
            int a = sc.nextInt();
            System.out.println("Digite o segundo valor:");
            int b = sc.nextInt();
            // Chamando o método remoto 

            double resultado = 0;
            switch(operacao) {
                case 1:
                    resultado = stub.soma(a, b);
                    break;
                case 2:
                    resultado = stub.subtrai(a, b);
                    break;
                case 3:
                    resultado = stub.multiplica(a, b);
                    break;
                case 4:
                    resultado = stub.dividi(a, b);
                    break;
            }

            System.out.println("Resultado: " + resultado);
        } catch (Exception e) {
            System.err.println("Exceção do Cliente: " + e.toString());
            e.printStackTrace();
        }
    }
}
