/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplo1;

/**
 *
 * @author profslpa
 */
public class Produto {
    private String nome;
    private String marca;
    private double preco;
    private double peso;

    Produto(String nome, String marca, double preco, double peso) {
        this.nome = nome;
        this.marca = marca;
        this.preco = preco;
        this.peso = peso;
    }

    public void setPreco(double preco) {
        this.preco = preco;
    }

    public String toString() {
        return nome + " da marca " + marca + 
                " custa R$" + preco;
    }
}
