/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplo1;

/**
 *
 * @author profslpa
 */
public class Main {

    public static void main(String args[]) {
        // exemplo1();
        exercicio3();
    }
    
    public static void exemplo1() {
        Pessoa pedro = new Pessoa("Pedro", 24);
        
        pedro.setIdade(25);
        
        System.out.println("A pessoa chama " + 
                pedro.getNome() + " e ela tem " + 
                pedro.getIdade() + " anos.");
        
        pedro.andar();

    }
    
    public static void exercicio1() {
        Produto bolacha = new Produto("Bolacha", "Oreo", 3.00, 100);
        bolacha.setPreco(3.50);
        
        System.out.println(bolacha);
    }
    
    public static void exercicio2() {
        Carro carro = new Carro("CXP2A00", "vermelho", 30000);
        carro.acelerar();
        carro.acelerar();
        carro.acelerar();

        carro.mostrarVelocidade();
        carro.abrirPorta();
        
        Moto moto = new Moto("azul", 7000);
        moto.acelerar();
        moto.mostrarVelocidade();
    }
    
    public static void exemploClasseAbstrata() {
        Humano humano = new Humano();
        Leao leao = new Leao();
        
        humano.falar();
        leao.falar();
    }
    
    public static void exercicio3() {
        
        Circulo c = new Circulo(10);
        System.out.println("A área do círculo é " + c.calcularArea());
        
        Quadrado q = new Quadrado(5);
        System.out.println("A área do quadrado é " + q.calcularArea());
    }
}
