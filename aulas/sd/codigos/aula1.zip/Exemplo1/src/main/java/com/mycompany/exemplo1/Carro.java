/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplo1;

/**
 *
 * @author profslpa
 */
public class Carro extends Veiculo {
    Carro(String placa, String cor, double preco) {
        this.placa = placa;
        this.cor = cor;
        this.preco = preco;
    }
    
    @Override
    public void acelerar() {
        velocidade = velocidade + 10;
    }
    
    public void abrirPorta() {
        System.out.println("A porta do carro foi aberta.");
    }
}
