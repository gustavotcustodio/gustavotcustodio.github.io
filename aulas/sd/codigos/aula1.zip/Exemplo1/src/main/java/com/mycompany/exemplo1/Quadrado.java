/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exemplo1;

/**
 *
 * @author profslpa
 */
public class Quadrado extends Forma {
    private double lado;
    
    Quadrado(double lado) {
        this.lado = lado;
    }
    
    public double calcularArea() {
        return lado * lado;
    }
}
