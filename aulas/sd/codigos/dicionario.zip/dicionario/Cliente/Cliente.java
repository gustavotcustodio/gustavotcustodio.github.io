import java.util.Scanner;
import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;

public class Cliente {
    public static void main(String[] args) {
        try {
            Scanner sc = new Scanner(System.in);

            // Pegando o registro 
            Registry registry = LocateRegistry.getRegistry("localhost", 18000);

            // Procurando por um registro que utilize a Interface Dicionario
            Dicionario stub = (Dicionario) registry.lookup("Dicionario");

            System.out.print("Digite a palavra buscada: ");
            String palavraPort = sc.nextLine();
            String palavraIng = stub.procuraPalavra(palavraPort);
            System.out.println(palavraIng);

        } catch(Exception e){
            e.printStackTrace();
        }
    }
}
