import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.rmi.server.UnicastRemoteObject;

public class Server extends DicionarioImpl {

    public static void main(String args[]) {
        try {
            // Instanciação
            DicionarioImpl obj = new DicionarioImpl();

            // Exportando o objeto para o stub
            Dicionario stub = (Dicionario) UnicastRemoteObject.exportObject(obj, 0);

            // Binding o objeto remoto (stub) no registro
            Registry registry = LocateRegistry.createRegistry(18000);
            registry.rebind("Dicionario", stub);


            System.err.println("Servidor Pronto");
        } catch (Exception e) {
            System.err.println("Exceção do Servidor: " + e.toString());
            e.printStackTrace();
        }
    }
    
}
