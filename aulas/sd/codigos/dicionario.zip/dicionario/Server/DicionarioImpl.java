import java.io.BufferedReader;
import java.io.FileReader;

public class DicionarioImpl implements Dicionario {


    public String procuraPalavra(String palavraPort) throws java.rmi.RemoteException {
        try {
            BufferedReader br = new BufferedReader(new FileReader("dicionario.txt"));
            String line = br.readLine();
            while (line != null) {
                // Separa a linha em duas palavras
                String[] palavras = line.split(",");

                String portugues = palavras[0];
                String ingles = palavras[1];

                if (palavraPort.equalsIgnoreCase(portugues)) {
                    System.out.println("palavra encontrada.");
                    return ingles;
                }
                // Lê a próxima linha do arquivo
                line = br.readLine();

            }
        } catch(Exception e){
            e.printStackTrace();
            return "Palavra não encontrada";
        }
        return "Palavra não encontrada";
    }

}
