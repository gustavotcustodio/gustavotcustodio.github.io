/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicios;

/**
 *
 * @author profslpa
 */
public class Imovel {
    protected String endereco;
    protected double preco;
    
    Imovel(String endereco, double preco) {
        this.endereco = endereco;
        this.preco = preco;
    }
    
    Imovel(String endereco) {
        // Se você não disse o preço da casa, por padrão custa 500k
        this.endereco = endereco;
        this.preco = 500000;
    }
    
    public void mostrarPreco() {
        System.out.println("O imóvel no endereço " + endereco + 
                " custa " + converterMonetario(preco));
    }
    
    public String converterMonetario(double valor) {
        return String.format("R$ %,.2f", valor);
    }
}
