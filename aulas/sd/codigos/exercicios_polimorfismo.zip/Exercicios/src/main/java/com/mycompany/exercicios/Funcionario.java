/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicios;

/**
 *
 * @author profslpa
 */
public class Funcionario {
    public String nome;
    public String cargo;
    public double salario;
    
    Funcionario(String nome, String cargo, double salario) {
        this.nome = nome;
        this.cargo = cargo;
        this.salario = salario;
    }

    public String getNome() {
        return nome;
    }

    public String getCargo() {
        return cargo;
    }

    public double getSalario() {
        return salario;
    }
    
    public void setSalario(double salario) {
        this.salario = salario;
    }
    
    public void setCargo(String cargo) {
        this.cargo = cargo;
    }
    
    public String toString() {
        return "O funcionário " + nome + " é um " +
                cargo + " e ganha " + 
                String.format("R$ %,.2f", salario);
    }
}
