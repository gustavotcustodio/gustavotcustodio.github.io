/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicios;

/**
 *
 * @author profslpa
 */
public class VelhoImovel extends Imovel{
    private double desconto;
    
    public VelhoImovel(String endereco, double preco, double desconto) {
        super(endereco, preco);
        this.desconto = desconto;
    }

    @Override
    public void mostrarPreco() {
        double precoFinal = preco - desconto;
        System.out.println("O imóvel no endereco " + endereco + 
                " custa " + converterMonetario(precoFinal) +
                " com um desconto de " + 
                converterMonetario(desconto));
    }
}
