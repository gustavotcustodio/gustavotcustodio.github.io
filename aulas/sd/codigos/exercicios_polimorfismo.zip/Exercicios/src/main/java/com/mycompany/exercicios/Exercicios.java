/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicios;

import java.util.ArrayList;

/**
 *
 * @author profslpa
 */
public class Exercicios {
    public static void main(String[] args) {
        exercicio5();
    }
    
    public static void exercicio4() {
        ArrayList<Imovel> imoveis = new ArrayList<>();
        
        Imovel imovelNormal = new Imovel("Av Paulista 2000");
        Imovel imovelNovo = new NovoImovel("Rua Augusta 100", 700000, 100000);
        VelhoImovel imovelVelho = new VelhoImovel("Rua Antiga 90", 300000, 50000);
        imoveis.add(imovelNormal);
        imoveis.add(imovelNovo);
        imoveis.add(imovelVelho);
        
        for(Imovel i : imoveis) {
            i.mostrarPreco();
        }
    }
    
    public static void exercicio5() {
        Funcionario f = new Funcionario("João", "Estagiário", 2000);
        Gerente g = new Gerente("Manuel");
        g.atualizar(f, "Analista");
        g.atualizar(f, 3000);
        
        System.out.println(f);
    }
    
}
