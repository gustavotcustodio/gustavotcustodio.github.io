/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.exercicios;

/**
 *
 * @author profslpa
 */
public class Gerente extends Funcionario{
    
    
    Gerente(String nome) {
        /*
        this.nome = nome;
        this.cargo = "gerente";
        this.salario = 10000;*/
        super(nome, "gerente", 10000);
    }
    
    public void atualizar(Funcionario f, String cargo) {
        f.setCargo(cargo);
    }
    
    public void atualizar(Funcionario f, double salario) {
        f.setSalario(salario);
    }
}
