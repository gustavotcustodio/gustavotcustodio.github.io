/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.polimorfismo;

/**
 *
 * @author profslpa
 */
public class Ave {
    public void introduzir() {
        System.out.println("Existem muitas aves.");
    }
    
    public void voar() {
        System.out.println("A maioria das aves podem voar, " + 
                "mas algumas não.");
    }
}
