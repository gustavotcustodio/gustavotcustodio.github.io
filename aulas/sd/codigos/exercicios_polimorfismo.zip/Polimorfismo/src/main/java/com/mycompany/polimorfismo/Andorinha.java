/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.polimorfismo;

/**
 *
 * @author profslpa
 */
public class Andorinha extends Ave {
    @Override
    public void introduzir() {
        System.out.println("Existem muitas aves e a andorinha " +
                "é uma delas.");
    }
    
    @Override
    public void voar() {
        System.out.println("Andorinha pode voar.");
    }
}
