/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package com.mycompany.polimorfismo;

import java.util.ArrayList;

/**
 *
 * @author profslpa
 */
public class ExemploPoilimorfismo {
    public static void main(String args[]) {
        ArrayList<Ave> aves = new ArrayList<>(); 
        
        Ave a = new Ave();
        aves.add(a);
        
        Cegonha c = new Cegonha();
        aves.add(c);
                
        Avestruz az = new Avestruz();
        aves.add(az);
        
        Andorinha and = new Andorinha();
        aves.add(and);
        /*
        for (int i = 0; i < aves.size(); i++) {
            Ave ave = aves.get(i);
            ave.introduzir();
            ave.voar();
            System.out.println("------------------------------------");
        }*/
        
        for (Ave individuo : aves) {
            individuo.introduzir();
            individuo.voar();
            System.out.println("------------------------------------");
        }
    }
}
