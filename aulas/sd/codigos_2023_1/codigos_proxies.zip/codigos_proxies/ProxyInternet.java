import java.util.ArrayList;

/**
 * ProxyInternet
 */
public class ProxyInternet implements Internet {
    // Lista de sites banidos
    private ArrayList<String> bannedSites = new ArrayList<>();
    
    // O objeto que corresponde ao que o cliente quer acessar de verdade
    private final Internet internet = new RealInternet();

    // Construtor para adicionar a lista de sites banidos
    public ProxyInternet() {
        bannedSites.add("www.youtube.com");
        bannedSites.add("www.tiktok.com");
        bannedSites.add("www.instagram.com");
        bannedSites.add("www.ulife.com.br");
    }

    @Override
    public void connectTo(String serverhost) throws Exception {
        // Verificamos se o cliente acessou um site banido
        if (bannedSites.contains(serverhost.toLowerCase())) {
            // Se um site da lista de sites banidos for encontrado, mostra uma exceção de acesso negado
            throw new Exception("Acesso negado para " + serverhost);
        }

        // Conexão real
        internet.connectTo(serverhost);
    }
}