
public interface Internet {
    // Método para se conectar a um site
    public void connectTo(String serverhost) throws Exception;
}