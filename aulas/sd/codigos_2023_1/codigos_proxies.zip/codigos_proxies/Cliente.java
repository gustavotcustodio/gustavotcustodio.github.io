public class Cliente {
    public static void main(String[] args) {
        conectarProxy();
    }

    public static void conectarProxy() {
        // Substituindo a implementação original pelo proxy
        Internet internet = new ProxyInternet();

        try {
            // Uma requisição permitida
            String siteName = "www.stackoverflow.com";
            internet.connectTo(siteName);

            // Uma requisição proibida
            siteName = "www.tiktok.com";
            internet.connectTo(siteName);

        } catch (Exception e) {
            // o getMessage mostra a mensagem da exceção
            System.out.println(e.getMessage());
        }
    }
}
