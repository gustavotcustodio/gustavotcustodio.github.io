/*
 * A classe responsável por realmente acessar a internet
 */
public class RealInternet implements Internet {

    @Override
    public void connectTo(String serverhost) {
        System.out.println("Conectando com " + serverhost + "...");

        try {
            // Isso só serve para esperar por 3 segundos
            // Senão fica muito rápido
            Thread.sleep(3000);
            System.out.println("Conectado com sucesso!");
        } catch (InterruptedException ex) {
            // Se der algum problema, exceção.
            System.out.println("Erro!!");
        }


    }

}
