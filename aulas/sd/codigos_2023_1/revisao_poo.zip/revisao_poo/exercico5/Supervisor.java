public class Supervisor implements Funcionario {
    private int qtdSupervisionados;
    private double salarioBase;
    private String nome;

    public Supervisor(String nome, int qtdSupervisionados, double salarioBase) {
        this.nome = nome;
        this.qtdSupervisionados = qtdSupervisionados;
        this.salarioBase = salarioBase;
    }

    @Override
    public double calcularSalario() {
        return salarioBase * qtdSupervisionados;
    }

    @Override
    public String toString() {
        return nome + " supervisiona " + qtdSupervisionados + " pessoas " + 
        "e ganha R$" + calcularSalario();
    }
}