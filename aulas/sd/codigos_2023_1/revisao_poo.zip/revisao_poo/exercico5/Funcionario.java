public interface Funcionario {
    public double calcularSalario();
}