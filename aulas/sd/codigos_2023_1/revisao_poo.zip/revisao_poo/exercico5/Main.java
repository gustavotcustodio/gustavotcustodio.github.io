import java.util.ArrayList;

public class Main {
    public static void main(String[] args) {
        // Aqui eu crio um supervisor e 3 estagiários
        Funcionario supervisor = new Supervisor("Márcio", 10, 1000);

        Funcionario estagiario1 = new Estagiario("CCO", "Null da Silva", 20, 30);

        Funcionario estagiario2 = new Estagiario("SI", "Fulano da Silva", 20, 30);

        Funcionario estagiario3 = new Estagiario("ADS", "João da Silva", 20, 30);

        // Colocar todos em uma lista´´
        ArrayList<Funcionario> listaFuncionarios = new ArrayList<>();

        listaFuncionarios.add(estagiario1);
        listaFuncionarios.add(estagiario2);
        listaFuncionarios.add(estagiario3);
        listaFuncionarios.add(supervisor);

        for (Funcionario funcionario : listaFuncionarios) {
            System.out.println(funcionario);
        }
    }
}
