public abstract class Estudante {
    private String curso;
    private String nome;
    private int horasEstudoSemana;

    public Estudante(String curso, String nome, int horasEstudoSemana) {
        this.curso = curso;
        this.nome = nome;
        this.horasEstudoSemana = horasEstudoSemana;
    }

    public String getCurso() {
        return curso;
    }

    public String getNome() {
        return nome;
    }

    public int getHorasEstudoSemana() {
        return horasEstudoSemana;
    }
}