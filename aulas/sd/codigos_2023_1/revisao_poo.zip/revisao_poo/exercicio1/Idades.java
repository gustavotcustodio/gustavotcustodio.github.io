import java.util.ArrayList;
import java.util.Scanner;

public class Idades {
    public static void main(String[] args) {
        Scanner sc = new Scanner(System.in);

        int idade = 0;

        // Criei a lista
        ArrayList<Integer> listaIdades = new ArrayList<>();

        // rode até digitar um número negativo
        while (idade >= 0) {
            System.out.println("Digite uma idade");
            // Leia a próxima idade
            idade = sc.nextInt();

            if (idade >= 0) {
                listaIdades.add(idade);
            }
        }

        // mostre todos os números no ArrayList armazenados até o momento
        for (Integer i : listaIdades) {
            System.out.println(i);
        }

        sc.close();
    }
}