/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */

/**
 *
 * @author 12522172106
 */
public class Exercicio1 {
    public static void main(String[] args) {
        Produto macarrao = new Produto(
                "Macarrão", "Renata", 5.0, 0.5);
        
        String oQueDevoMostrar = macarrao.toString();
        System.out.println(oQueDevoMostrar);
        
    }
}
