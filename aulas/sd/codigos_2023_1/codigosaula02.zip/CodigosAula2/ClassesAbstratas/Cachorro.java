public class Cachorro extends Animal {
    public void falar() {
        System.out.println("au au au");
    }
}
