public class Leao extends Animal {
    public void falar() {
        System.out.println("Roooaaar");
    }
}
