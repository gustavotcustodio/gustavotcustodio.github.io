/**
 * Animal
 */
public abstract class Animal {

    public abstract void falar();

}