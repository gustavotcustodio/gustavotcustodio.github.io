public class Principal {
    public static void main(String[] args) {

        Humano human = new Humano();
        human.falar();

        Vaca cow = new Vaca();
        cow.falar();

        Cachorro dog = new Cachorro();
        dog.falar();
    }
}
