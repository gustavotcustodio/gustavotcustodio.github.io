public class Vaca extends Animal {
    public void falar() {
        System.out.println("Moo");
    }
}
