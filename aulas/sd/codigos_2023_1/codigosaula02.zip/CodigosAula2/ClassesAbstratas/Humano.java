public class Humano extends Animal {
    public void falar() {
        System.out.println("Eu posso falar: blablabla");
    } 
}
