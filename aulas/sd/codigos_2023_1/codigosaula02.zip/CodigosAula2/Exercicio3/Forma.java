/**
 * Forma
 */
public abstract class Forma {
    protected String cor;

    public abstract double calcArea(); 
}