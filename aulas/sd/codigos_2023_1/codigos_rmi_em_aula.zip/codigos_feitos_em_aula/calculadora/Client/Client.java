import java.rmi.registry.LocateRegistry;
import java.rmi.registry.Registry;
import java.util.Scanner;

public class Client {
    public static void main(String[] args) {
        try {
            Scanner sc = new Scanner(System.in);
            // Pegando o registro8000); 
            Registry registry = LocateRegistry.getRegistry("127.0.0.1", 18000);

            // Procurando por um registro que utilize a Interface Hello
            Calculadora stub = (Calculadora) registry.lookup("Calculadora");

            System.out.println("Digite o primeiro valor:");
            int a = sc.nextInt();
            System.out.println("Digite o segundo valor:");
            int b = sc.nextInt();

            System.out.println(
                "Digite a operação\n" +
                "1 - Adição\n" +
                "2 - Subtração\n" +
                "3 - Multiplicação\n" +
                "4 - Divisão"
            );
            int operacao = sc.nextInt();

            switch (operacao) {
                case 1:
                    int soma = stub.soma(a, b);
                    System.out.println("Soma: " + soma);
                    break;
                case 2:
                    int subtracao = stub.subtrai(a, b);
                    System.out.println("Subtração: " + subtracao);
                    break;
                case 3:
                    int multiplicacao = stub.multiplica(a, b);
                    System.out.println("Multiplicação: " + multiplicacao);
                    break;
                case 4:
                    double divisao = stub.divide((double)a, (double)b);
                    System.out.println("Divisão: " + divisao);
                    break;
                default:
                    System.out.println("Operação inválida!!");
                    break;
            }
            
        } catch (Exception e) {
            System.err.println("Exceção do Cliente: " + e.toString());
            e.printStackTrace();
        }
    }
}
