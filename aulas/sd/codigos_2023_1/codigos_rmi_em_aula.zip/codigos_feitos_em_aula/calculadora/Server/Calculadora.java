import java.rmi.Remote;

public interface Calculadora extends Remote {
    
    public int soma(int a, int b) throws java.rmi.RemoteException;

    public int subtrai(int a, int b) throws java.rmi.RemoteException;

    public int multiplica(int a, int b) throws java.rmi.RemoteException;

    public double divide(double a, double b) throws java.rmi.RemoteException;
}
