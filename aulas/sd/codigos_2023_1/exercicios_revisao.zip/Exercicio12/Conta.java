/**
 * Conta
 */
public interface Conta {

    public void acessarConta(String username, String senha) throws Exception;


}